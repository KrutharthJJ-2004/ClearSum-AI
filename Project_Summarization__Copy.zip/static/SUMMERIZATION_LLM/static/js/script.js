// DOM Ready
document.addEventListener('DOMContentLoaded', function() {
    initializeFileUpload();
    initializeFormHandlers();
    initializeCopyButtons();
});

// File Upload Handling
function initializeFileUpload() {
    const inputType = document.getElementById('inputType');
    const textInputSection = document.getElementById('textInputSection');
    const fileInputSection = document.getElementById('fileInputSection');
    const fileInput = document.getElementById('file');
    const fileInfo = document.getElementById('fileInfo');

    if (inputType && textInputSection && fileInputSection) {
        inputType.addEventListener('change', function() {
            if (this.value === 'file') {
                textInputSection.style.display = 'none';
                fileInputSection.style.display = 'block';
            } else {
                textInputSection.style.display = 'block';
                fileInputSection.style.display = 'none';
            }
        });
    }

    if (fileInput && fileInfo) {
        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                fileInfo.innerHTML = `
                    <strong>Selected file:</strong> ${file.name}<br>
                    <small>Size: ${(file.size / 1024 / 1024).toFixed(2)} MB</small>
                `;
            } else {
                fileInfo.innerHTML = '';
            }
        });
    }
}

// Form Submission
function initializeFormHandlers() {
    const form = document.getElementById('summarizeForm');
    const summarizeBtn = document.getElementById('summarizeBtn');
    const resultSection = document.getElementById('resultSection');
    const loadingSection = document.getElementById('loadingSection');
    const newSummaryBtn = document.getElementById('newSummaryBtn');

    if (form) {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const inputType = document.getElementById('inputType').value;
            
            // Validate input
            if (inputType === 'text' && !formData.get('text').trim()) {
                alert('Please enter some text to summarize.');
                return;
            }
            
            if (inputType === 'file' && !formData.get('file').name) {
                alert('Please select a file to upload.');
                return;
            }

            // Show loading, hide form and previous results
            summarizeBtn.disabled = true;
            form.style.display = 'none';
            loadingSection.style.display = 'block';
            resultSection.style.display = 'none';

            try {
                const response = await fetch('/summarize', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (response.ok) {
                    // Show success result
                    document.getElementById('summaryResult').textContent = data.summary;
                    resultSection.style.display = 'block';
                } else {
                    // Show error
                    alert('Error: ' + data.error);
                    form.style.display = 'block';
                }
            } catch (error) {
                alert('Network error: ' + error.message);
                form.style.display = 'block';
            } finally {
                loadingSection.style.display = 'none';
                summarizeBtn.disabled = false;
            }
        });
    }

    if (newSummaryBtn) {
        newSummaryBtn.addEventListener('click', function() {
            resultSection.style.display = 'none';
            form.style.display = 'block';
            form.reset();
            document.getElementById('fileInfo').innerHTML = '';
        });
    }
}

// Copy to Clipboard
function initializeCopyButtons() {
    // Copy button in upload page
    const copyBtn = document.getElementById('copyBtn');
    if (copyBtn) {
        copyBtn.addEventListener('click', function() {
            const summaryText = document.getElementById('summaryResult').textContent;
            copyToClipboard(summaryText);
            showNotification('Summary copied to clipboard!', 'success');
        });
    }

    // Copy button in summary detail page
    const copySummaryBtn = document.getElementById('copySummaryBtn');
    if (copySummaryBtn) {
        copySummaryBtn.addEventListener('click', function() {
            const summaryText = document.getElementById('aiSummary').textContent;
            copyToClipboard(summaryText);
            showNotification('Summary copied to clipboard!', 'success');
        });
    }
}

function copyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
}

function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type}`;
    notification.textContent = message;
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '10000';
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Drag and Drop File Upload
document.addEventListener('DOMContentLoaded', function() {
    const fileUploadArea = document.querySelector('.file-upload-area');
    const fileInput = document.getElementById('file');
    
    if (fileUploadArea && fileInput) {
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            fileUploadArea.addEventListener(eventName, preventDefaults, false);
        });
        
        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        ['dragenter', 'dragover'].forEach(eventName => {
            fileUploadArea.addEventListener(eventName, highlight, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            fileUploadArea.addEventListener(eventName, unhighlight, false);
        });
        
        function highlight() {
            fileUploadArea.style.borderColor = 'var(--accent-blue)';
            fileUploadArea.style.background = 'rgba(25, 118, 210, 0.1)';
        }
        
        function unhighlight() {
            fileUploadArea.style.borderColor = 'var(--border-color)';
            fileUploadArea.style.background = '';
        }
        
        fileUploadArea.addEventListener('drop', handleDrop, false);
        
        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            fileInput.files = files;
            
            // Trigger change event
            const event = new Event('change', { bubbles: true });
            fileInput.dispatchEvent(event);
        }
    }
});